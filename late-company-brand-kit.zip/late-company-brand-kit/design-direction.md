# Late Company visual direction

Working name for a Metro Detroit social coworking lounge and cafe. Concept in development.

## Palette
- Aubergine #251820: page ground, night atmosphere
- Burgundy #58313D: secondary fields, seating reference
- Lamplight #E9B86F: primary action, logo symbol
- Oyster #F4EBDD: body text and soft contrast
- Stone #C1AFAF: secondary text
- Moss #778678: small supporting accent

## Typography
Georgia display serif in broad, generous lines. System sans serif for practical details. The wordmark has a compact two-line lockup, with a lit-window symbol occupying the height of both lines. Core font stacks require no third-party request.

## Layout
Photography carries the first screen: a large horizontal scene with an oversized two-line headline at the left. Header aligns a real logo left, navigation right. Main copy and interest actions stay left aligned. Below, open asymmetric sections shift from communal lounge to focused table.

[logo                       idea / space / interest]
[                                    photograph  ]
[Good company.                                   ]
[Even late.            short promise + CTA        ]
[                      image caption             ]
[story heading         plain copy                ]
[image detail          ways to settle in         ]
[concept hours         interest email form       ]

## Principles
Make the welcome and warm room memorable. A lamp-lit window is the key motif. Avoid coworking dashboard cards, nightclub neon, fake activity metrics, or a location implied to exist. Use one short opening animation and clear interaction states.

## Critique before implementation
A cream editorial grid could feel like a brochure. The revised first screen puts a warm interior across the full width and moves large text into the photograph. The page stays dark. Quieter content uses spacing rather than identical cards. The interested visitor gets one clear action that describes its email behavior.
