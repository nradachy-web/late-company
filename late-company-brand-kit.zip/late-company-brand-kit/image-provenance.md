# Image and artwork provenance

Created October 3, 2026 for the Late Company concept.

## Generated design studies
The hero, detail image and logo exploration were generated with the built-in OpenAI image generation tool. Imagen and Higgsfield were not used. These are imagined design studies, not photographs of an operating business, leased space or actual customers.

Creative briefs, summarized:
- lounge-hero.png: A wide, photoreal Metro Detroit night lounge with rainy street windows, walnut tables, burgundy seating, brass lamps, quiet work and a small board-game gathering. Warm and relaxed, with no nightclub lighting or logos.
- lounge-detail.png: A warm close view of a lamp, coffee and board game, with two adult friends talking in a comfortable lounge.
- logo-exploration.png: An oyster presentation sheet exploring the Late Company serif wordmark and two companion windows in burgundy and lamplight gold.

Keep an AI concept-image disclosure near any public use that could otherwise be mistaken for a real venue. No property, opening date or fit-out is implied.

## Production assets
The SVG family is separately constructed, editable vector artwork. PNG exports are rendered from these SVGs using MuPDF, with transparent backgrounds where appropriate. SVG text remains editable and may render differently when the target machine uses a fallback font. Review and outline wordmark text before fabrication. PNG exports fix their displayed appearance. No font files are included.

The name is provisional. See README.md for the limited name screen and next checks.
